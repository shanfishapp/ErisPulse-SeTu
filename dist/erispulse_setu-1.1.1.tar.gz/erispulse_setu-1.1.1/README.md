# ErisPulse-SeTu
这是一个ErisPulse的色图插件，API地址：<https://api.lolicon.app/setu/v2>  
您可以使用其中之一的指令来触发本插件：
- `/随机色图`
- `随机色图`
- `/色图`，
- `色图`

本模块已经支持流式下载和上传文件。

## 参考链接

- [ErisPulse 主库](https://github.com/ErisPulse/ErisPulse/)
- [ErisPulse 官方文档](https://www.erisdev.com)